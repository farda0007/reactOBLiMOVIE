import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Movie, MovieResults } from '../Types/movies';

const moviesApi = createApi({
  reducerPath: 'movies',
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://api.themoviedb.org/3/',
  }),
  tagTypes: ['FavoriteMovies'],
  endpoints: (builder) => ({
    fetchPopularMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'discover/movie',
        params: {
          sort_by: 'popularity.desc',
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(),
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title, // Adjusted to use original_title
            genres: movie.genre_ids,
          } as Movie;
        });
      },
    }),

    fetchHighestRatedMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'discover/movie',
        params: {
          sort_by: 'vote_average.desc',
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(),
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title, 
            genres: movie.genre_ids,
          } as Movie;
        });
      },
    }),

    fetchSearchMovie: builder.query<Movie[], { searchTerm: string }>({
      query: ({searchTerm}) => ({
        url: 'search/movie',
        params: {
          query: searchTerm,
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(),
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title, // Adjusted to use original_title
            genres: movie.genre_ids,
          } as Movie;
        });
      },
    }),

    fetchUpcomingMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'movie/upcoming',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(),
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title, // Adjusted to use original_title
            genres: movie.genre_ids,
            vote_average: movie.vote_average,
          } as Movie;
        });
      },
    }),
    fetchMovieTrailer: builder.query<{ id: string; key: string; site: string; type: string } | null, number>({
      query: (movieId) => ({
        url: `movie/${movieId}/videos`,
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: { id: string; key: string; site: string; type: string }[] }) => {
        const trailers = response.results.filter(video => video.type === 'Trailer' && video.site === 'YouTube');
        return trailers.length ? trailers[0] : null; 
      },
    }), 
    // Managing favorite movies via JSON-Server
    getFavoriteMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'http://localhost:5174/favorites',
      }),
      providesTags: ['FavoriteMovies'],
    }),

    addFavoriteMovie: builder.mutation<void, Movie>({
      query: (movie) => ({
        url: 'http://localhost:5174/favorites',
        method: 'POST',
        body: movie,
      }),
      invalidatesTags: ['FavoriteMovies'],
    }),

    removeFavoriteMovie: builder.mutation<void, string>({
      query: (id) => ({
        url: `http://localhost:5174/favorites/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['FavoriteMovies'],
    }),
    fetchTvSeries: builder.query<Movie[], void>({
      query: () => ({
        url: 'discover/tv', // Endpoint for TV series
        params: {
          sort_by: 'popularity.desc',
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((tvSeries) => {
          return {
            id: tvSeries.id.toString(),
            adult: tvSeries.adult,
            poster_path: tvSeries.poster_path,
            overview: tvSeries.overview,
            release_date: tvSeries.first_air_date, // Use first_air_date for TV series
            title: tvSeries.name, // TV series have 'name' as title
            genres: tvSeries.genre_ids,
          } as Movie;
        });
      },
    }),
    
    fetchMovieGenres: builder.query<{ id: number; name: string }[], void>({
      query: () => ({
        url: 'genre/movie/list',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { genres: { id: number; name: string }[] }) => {
        return response.genres;
      },
    }),

    fetchTVGenres: builder.query<{ id: number; name: string }[], void>({
      query: () => ({
        url: 'genre/tv/list',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { genres: { id: number; name: string }[] }) => {
        return response.genres;
      },
    }),
    // Search for movies by director (this is a bit of a workaround by using 'with_crew' search)
    fetchMoviesByDirector: builder.query<Movie[], { directorName: string }>({
      query: ({ directorName }) => ({
        url: 'search/person',
        params: {
          query: directorName,
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: async (response: { results: any[] }) => {
        // First, find the director(s) matching the name
        const director = response.results.find(
          (person) => person.known_for_department === 'Directing'
        );
    
        if (director) {
          // Now fetch the movies directed by this person using their id
          const movieResponse = await fetch(
            `https://api.themoviedb.org/3/person/${director.id}/movie_credits?api_key=81c50c197b83129dd4fc387ca6c8c323`
          );
          const movieData = await movieResponse.json();
    
          // Return only the directed movies (exclude other types of works like writing, producing, etc.)
          return movieData?.crew?.filter((movie) => movie.job === 'Director').map((movie) => ({
            id: movie.id.toString(),
            title: movie.title,
            release_date: movie.release_date,
            poster_path: movie.poster_path,
            overview: movie.overview,
            genres: movie.genre_ids,
          }));
        }
    
        return [];
      },
    }),    
  }),
});

export const {
  useFetchPopularMoviesQuery,
  useFetchHighestRatedMoviesQuery,
  useFetchSearchMovieQuery,
  useFetchUpcomingMoviesQuery,
  useFetchMovieTrailerQuery,
  useGetFavoriteMoviesQuery,
  useAddFavoriteMovieMutation,
  useRemoveFavoriteMovieMutation,
  useFetchTvSeriesQuery,
  useFetchMovieGenresQuery,
  useFetchTVGenresQuery,
  useFetchMoviesByDirectorQuery,
} = moviesApi;

export { moviesApi };
