import { configureStore } from '@reduxjs/toolkit';
import { setupListeners } from '@reduxjs/toolkit/query/react';
import { moviesApi } from './api/moviesAPI'; // Correcting the variable name to match what you export
import { searchMovieReducer, changeSearchTerm } from './searchMovieSlice';

export const store = configureStore({
  // Define reducers here
  reducer: {
    [moviesApi.reducerPath]: moviesApi.reducer, // Correct name of the api reducer
    searchMovie: searchMovieReducer, // Add your custom reducer for searchMovie
  },
  middleware: (getDefaultMiddleware) => {
    return getDefaultMiddleware()
      .concat(moviesApi.middleware); // Ensure API middleware is used
  },
});

// Optional: Check the state and setup listeners (not necessary for production, just for debugging)
console.log(store.getState());
console.log(searchMovieReducer);
console.log(changeSearchTerm);

// Setup listeners for automatic refetching and caching
setupListeners(store.dispatch);

// Export API hooks and other actions
export { 
  useFetchPopularMoviesQuery, 
  useFetchHighestRatedMoviesQuery, 
  useFetchSearchMovieQuery,
  useFetchUpcomingMoviesQuery,
  useFetchMovieTrailerQuery,
  useGetFavoriteMoviesQuery, 
  useAddFavoriteMovieMutation, 
  useRemoveFavoriteMovieMutation ,
  useFetchTvSeriesQuery,
  useFetchMovieGenresQuery,
  useFetchTVGenresQuery,
  useFetchMoviesByDirectorQuery
} from './api/moviesAPI';
export { changeSearchTerm };
export type RootState = ReturnType<typeof store.getState>;