import { useFetchUpcomingMoviesQuery } from "../store";
import MovieCard from "./movieCard"
import React from "react";  

function UpcomingMoviesList() {
    const { data, error, isFetching } = useFetchUpcomingMoviesQuery();
  
    let content;
  if (isFetching) {
    content = <div>Loading...</div>;
  } else if (error) {
    content = <div>Error loading upcoming movies.</div>;
  } else {
    content = data
      ?.filter(movie => movie.poster_path && movie.vote_average !== undefined) // Ensure vote_average is present
      .map(movie => <MovieCard key={movie.id} movie={movie} />);
  }
  
    return (
      <div className="row row-cols-3 row-cols-md-2 m-4">
        {content}
      </div>
    );
  }
  
  export default UpcomingMoviesList;