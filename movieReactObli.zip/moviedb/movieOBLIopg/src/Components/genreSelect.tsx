import React from 'react';

const GenreSelect = ({
  genres,
  selectedGenre,
  onChange,
  label = 'Select Genre',
}: {
  genres: any[];
  selectedGenre: string;
  onChange: (genreId: string) => void;
  label?: string;
}) => {
  return (
    <div className="mb-3">
      <label>{label}</label>
      <select
        className="form-select"
        value={selectedGenre}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="">All</option>
        {genres.map((genre) => (
          <option key={genre.id} value={genre.id.toString()}>
            {genre.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default GenreSelect;
