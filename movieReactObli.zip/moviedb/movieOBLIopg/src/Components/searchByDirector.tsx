import React, { useState } from "react";
import { useFetchMoviesByDirectorQuery } from "../store";
import MovieCard from "./movieCard"; // Assuming you have a reusable MovieCard component

function SearchByDirector() {
  const [directorName, setDirectorName] = useState("");
  const [submittedName, setSubmittedName] = useState("");

  const { data = [], error, isFetching } = useFetchMoviesByDirectorQuery(
    { directorName: submittedName },
    { skip: !submittedName } // Prevent initial request
  );

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setDirectorName(event.target.value);
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (directorName.trim()) {
      setSubmittedName(directorName.trim());
    }
  };

  return (
    <div className="container mt-4">
      <form onSubmit={handleSubmit} className="mb-4">
        <label htmlFor="directorSearch" className="form-label">Search Movies by Director</label>
        <div className="d-flex">
          <input
            id="directorSearch"
            className="form-control me-2"
            value={directorName}
            onChange={handleInputChange}
            placeholder="Enter director name"
          />
          <button type="submit" className="btn btn-primary">Search</button>
        </div>
      </form>

      {isFetching && <div>Loading...</div>}
      {error && <div>Error fetching movies.</div>}
      {!isFetching && !error && data.length === 0 && submittedName && (
        <div>No movies found for director "{submittedName}".</div>
      )}

      <div className="row row-cols-1 row-cols-md-3 g-4">
        {data.flat().map((movie) =>
          movie && movie.poster_path && movie.title ? (
            <MovieCard key={movie.id} movie={movie} />
          ) : null
        )}
      </div>
    </div>
  );
}

export default SearchByDirector;