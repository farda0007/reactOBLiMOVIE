import { useFetchMovieTrailerQuery } from "../store";
import React from "react";

function MovieTrailer({ movieId }) {
  const { data: trailer, error, isFetching } = useFetchMovieTrailerQuery(movieId);

  let content;
  if (isFetching) {
    content = <div>Loading trailer...</div>;
  } else if (error) {
    content = <div>Error loading trailer.</div>;
  } else if (trailer) {
    content = (
      <iframe
        width="560"
        height="315"
        src={`https://www.youtube.com/embed/${trailer.key}`}
        title="Movie Trailer"
        frameBorder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      ></iframe>
    );
  } else {
    content = <div>No trailer available.</div>;
  }

  return <div className="trailer-container">{content}</div>;
}

export default MovieTrailer;