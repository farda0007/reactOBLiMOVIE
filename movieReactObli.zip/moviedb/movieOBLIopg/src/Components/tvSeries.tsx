import React from "react";
import { useFetchTvSeriesQuery } from "../store"; // Adjust if needed based on your API setup
import MovieCard from "./movieCard"; // You can create a separate card for TV series if you want, or reuse MovieCard

function TvSeriesList() {
  const { data, error, isFetching } = useFetchTvSeriesQuery();

  let content;
  if (isFetching) {
    content = <div>Loading...</div>;
  } else if (error) {
    content = <div>Error loading TV series.</div>;
  } else if (data) {
    content = data.map((tvSeries) => {
      return <MovieCard key={tvSeries.id} movie={tvSeries} />; // You can adjust if you need a different card for TV series
    });
  }

  return <div className="row row-cols-3 row-cols-md-2 m-4">{content}</div>;
}

export default TvSeriesList;
