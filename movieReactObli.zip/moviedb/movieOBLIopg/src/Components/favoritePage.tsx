import React from "react";
import { useGetFavoriteMoviesQuery } from "../store/api/moviesAPI";
import MovieCard from "./movieCard";

function FavoritePage() {
  const { data, error, isFetching } = useGetFavoriteMoviesQuery();

  let content;
  if (isFetching) {
    content = <div>Loading...</div>;
  } else if (error) {
    content = <div>Error loading favorite movies.</div>;
  } else if (data && data.length > 0) {
    content = data.map((movie) => (
      <MovieCard key={movie.id} movie={movie} />
    )); 
    
  } else {
    content = <div>No favorite movies added yet.</div>;
  }

  return <div className="row">{content}</div>;
}

export default FavoritePage;
